/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author seife
 */
// Subject ContractDAO_Imp 
public class ContractDAO_Imp implements ContractDAO {

    String messasge = "a new contract has been added to the database ";
    ArrayList<User> observers = new ArrayList<User>();

    public void AddObserver(User u) {
        observers.add(u);
    }

    public void notifyOb() {
        for (User u : observers) {
            u.addnot(messasge);
        }

    }

    @Override
    public boolean verifyContractID(Contract contract) throws SQLException {
        //connected to db

        //jdbc:derby://localhost:1527/CompanyDB
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "abc";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "SELECT * FROM CONTRACT WHERE CONTRACTID = '" + contract.getContractID() + "'";
        pst = con.prepareStatement(sqlQuery);
        rs = pst.executeQuery();
        while (rs.next()) {
            System.out.println(rs.getString("CONTRACTID"));
            return true;
        }
        return false;
        //Then check if it's assigned to this client
    }

    @Override
    public LinkedList<Contract> getAllContracts() throws SQLException {

        LinkedList<Contract> contracts = new LinkedList<>();
        //connected to db

        //jdbc:derby://localhost:1527/CompanyDB
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "abc";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "SELECT * FROM CONTRACT";
        pst = con.prepareStatement(sqlQuery);
        rs = pst.executeQuery();
        while (rs.next()) {
            String contractID = rs.getString("CONTRACTID");

            Contract c = new Contract("CONTRACTID");
            contracts.add(c);
        }
        return contracts;
        //Then check if it's assigned to this client
    }

    @Override
    public boolean insertContractData(Contract c) throws SQLException {

        //connected to db
        //jdbc:derby://localhost:1527/CompanyDB
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "abc";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "INSERT INTO CONTRACT(CONTRACTID, DATE, CLIENTID, PRICE) VALUES (?, ?, ?, ?)";
        pst = con.prepareStatement(sqlQuery);

        pst.setString(1, c.getContractID());
        pst.setString(2, c.getContractDate());
        pst.setString(3, c.getCreator());
        pst.setInt(4, c.getPrice());
        pst.executeUpdate();
        con.close();
        CEO.Delete();
        notifyOb();

        return true;
    }

    // can client edit contract? should we make it that a verification is sent to the CEO to agree on the edit?
    @Override
    public boolean EditContract(Contract c) throws SQLException {
        
        

        //connected to db
        //jdbc:derby://localhost:1527/CompanyDB
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "abc";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;
        
        

        String sqlQuery = "UPDATE CONTRACT SET PRICE = ? WHERE CONTRACTID = '" + c.getContractID() + "'";
        pst = con.prepareStatement(sqlQuery);

        pst.setInt(1, c.getPrice());

        pst.executeUpdate();

        con.close();
        return true;

    }

    public static void main(String[] args) throws SQLException {
        ContractDAO_Imp i = new ContractDAO_Imp();
        i.EditContract(new Contract("a111"));
        User u = new User("ahmed", "1234");
        User u1 = new User("ab3", "1223");
        i.AddObserver(u);
        i.AddObserver(u1);
        i.insertContractData(new Contract("1111"));
        i.insertContractData(new Contract("1112"));

        for (String s : u.not) {
            System.out.println(s);

        }
        for (String s : u1.not) {
            System.out.println(s);

        }

    }
}
