/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.SQLException;
import jakarta.jms.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author boica
 */
public class AddclientDAOIM implements AddClientDao{

    @Override
    public boolean AddClient(Client c) throws SQLException {
          String host="jdbc:derby://localhost:1527/project";
        String name="abc";
        String password="1234";
       java.sql.Connection con = DriverManager.getConnection(host, name, password);
        PreparedStatement pst = null;
        ResultSet rs = null;
        String SQlquery="INSEART INTO CLIENT(CLIENTID, PASSWORD) VALUES(?,?)";
        pst.setString(1, c.getUsername());
        pst.setString(2, c.getPassword());
        pst.executeUpdate();
        con.close();
        return true
  ;
        
        
    
    }
    
}
