/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author boica
 */
public class CEO extends User {

//    private static CEO c = new CEO("C123", "0000");
    private static CEO c ;

    public CEO(String username, String password) {
        super(username, password);
    }

    public static CEO getC() {
        if (c == null) {
            synchronized (CEO.class) {
                if (c == null) {
                    c = new CEO("C123", "0000");
                }
            }
        }
        return c;
    }
    public static void Delete (){
        CEO.c = null;
        
    }

}
