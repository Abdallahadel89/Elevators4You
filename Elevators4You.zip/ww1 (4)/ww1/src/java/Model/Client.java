/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author seife
 */
public class Client extends User{
    private ArrayList<Contract> contracts;
    private ArrayList<Project> projects;

    public Client(String username, String password) {
        super(username, password);
    }
    
    
}
