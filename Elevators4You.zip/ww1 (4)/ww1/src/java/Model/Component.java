/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author adhamoraby
 */
public class Component {
    private String comp_id ;
    private String comp_name;
    private String Type ;
    private int amount ;

    public Component(String comp_id, String comp_name, String Type, int amount) {
        this.comp_id = comp_id;
        this.comp_name = comp_name;
        this.Type = Type;
        this.amount = amount;
    }

    public String getComp_id() {
        return comp_id;
    }

    public void setComp_id(String comp_id) {
        this.comp_id = comp_id;
    }

    public String getComp_name() {
        return comp_name;
    }

    public void setComp_name(String comp_name) {
        this.comp_name = comp_name;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "Componenet{" + "comp_id=" + comp_id + ", comp_name=" + comp_name + ", Type=" + Type + ", amount=" + amount + '}';
    }
    
    
}

    

