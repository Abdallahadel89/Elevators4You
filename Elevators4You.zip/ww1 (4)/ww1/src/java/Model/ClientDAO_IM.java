/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

/**
 *
 * @author boica
 */
public class ClientDAO_IM implements ClientDAO {

    @Override
    public boolean VerifyClientID(Client c) throws SQLException {

        //jdbc:derby://localhost:1527/project
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "abc";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "SELECT * FROM CLIENT WHERE CLIENTID = '" + c.getUsername() + "' AND Password = '" + c.getPassword() + "'";

        pst = con.prepareStatement(sqlQuery);
        rs = pst.executeQuery();
        while (rs.next()) {
            System.out.println(rs.getString("CLIENTID"));
            return true;
        }
        return false;
        //Then check if it's assigned to this client
    }

    @Override
    public LinkedList<Client> Getclients() throws SQLException {
        LinkedList<Client> clients = new LinkedList<>();
        //connected to db

        //jdbc:derby://localhost:1527/CompanyDB
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "ABC";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "SELECT * FROM client";
        pst = con.prepareStatement(sqlQuery);
        rs = pst.executeQuery();
        while (rs.next()) {
            String clientID = rs.getString("clientid");
            String clientpass = rs.getString("password");

            Client c = new Client("clientid", "password");
            clients.add(c);
        }
        return clients;
    }
}
