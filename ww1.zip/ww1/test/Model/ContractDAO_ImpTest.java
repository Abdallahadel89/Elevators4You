/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Model;

import java.util.LinkedList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author seife
 */
public class ContractDAO_ImpTest {
    
    public ContractDAO_ImpTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of verifyContractID method, of class ContractDAO_Imp.
     */
    @Test
    public void testVerifyContractID() throws Exception {
        System.out.println("verifyContractID");
        Contract contract = new Contract("CO01", "18/12/22", "D001", 4050);
        ContractDAO_Imp instance = new ContractDAO_Imp();
        boolean expResult = false;
        boolean actualResult = instance.verifyContractID(contract);
        assertEquals(expResult, actualResult);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of getAllContracts method, of class ContractDAO_Imp.
     */
    @Test
    public void testGetAllContracts() throws Exception {
        System.out.println("getAllContracts");
        ContractDAO_Imp instance = new ContractDAO_Imp();
        LinkedList<Contract> expResult = null;
        LinkedList<Contract> result = instance.getAllContracts();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of insertContractData method, of class ContractDAO_Imp.
     */
    @Test
    public void testInsertContractData() throws Exception {
        System.out.println("insertContractData");
        Contract c = new Contract("CO01", "18/12/22", "D001", 4050);
        ContractDAO_Imp instance = new ContractDAO_Imp();
        boolean expResult = false;
        boolean result = instance.insertContractData(c);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    }

    /**
     * Test of EditContract method, of class ContractDAO_Imp.
     */
    @Test
    public void testEditContract() throws Exception {
        System.out.println("EditContract");
        Contract c = null;
        ContractDAO_Imp instance = new ContractDAO_Imp();
        instance.EditContract(c);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of AddObserver method, of class ContractDAO_Imp.
     */
    @Test
    public void testAddObserver() {
        System.out.println("AddObserver");
        User u = null;
        ContractDAO_Imp instance = new ContractDAO_Imp();
        instance.AddObserver(u);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class ContractDAO_Imp.
     */
    @Test
    public void testMain() throws Exception {
        System.out.println("main");
        String[] args = null;
        ContractDAO_Imp.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
