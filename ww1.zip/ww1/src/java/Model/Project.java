/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author seife
 */
public class Project {
    private String P_ID;
    private String p_name;
    private ArrayList<Component> c;
    
    public Project(String P_ID)
    {
        this.P_ID = P_ID;
        this.c = new ArrayList<>();
    }

    public Project(String P_ID, String p_name)
    {
        this.P_ID = P_ID;
        this.p_name = p_name;
        this.c = new ArrayList<>();
    }

    public ArrayList<Component> getC() {
        return c;
    }

    public void setC(ArrayList<Component> c) {
        this.c = c;
    }

    @Override
    public String toString() {
        return "Project Info: " + "P_ID=" + P_ID + ", p_name=" + p_name + ", c=" + c + '}';
    }

    public String getP_ID() {
        return P_ID;
    }

    public void setP_ID(String P_ID) {
        this.P_ID = P_ID;
    }

    public String getP_name() {
        return p_name;
    }

    public void setP_name(String p_name) {
        this.p_name = p_name;
    }

}
