/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

/**
 *
 * @author boica
 */
public class ceoDAO_im implements ceoDAO{

    
    public boolean VerifyCEO(CEO c) throws SQLException {
        
        //jdbc:derby://localhost:1527/CompanyDB
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "abc";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "SELECT * FROM CEO WHERE CEOID = '" + c.getUsername() + "' AND CEOPASS = '" + c.getPassword()+ "'";

        pst = con.prepareStatement(sqlQuery);
        rs = pst.executeQuery();
        while (rs.next()) {
            System.out.println(rs.getString("CEOID"));
            return true;
        }
        return false;
        //Then check if it's assigned to this client
    }
    

    @Override
    public LinkedList<CEO> getCEO() throws SQLException {
         LinkedList<CEO> CEOs = new LinkedList<>();
        //connected to db

        //jdbc:derby://localhost:1527/CompanyDB
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "ABC";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "SELECT * FROM CEO";
        pst = con.prepareStatement(sqlQuery);
        rs = pst.executeQuery();
        while (rs.next()) {
            String ID = rs.getString("ID");
            String PASS = rs.getString("pass");
            

            CEOs.add(CEO.getC());
        }
        return CEOs;
    }
    
   
    
    
}
