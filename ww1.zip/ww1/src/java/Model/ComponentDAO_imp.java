/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

/**
 *
 * @author adhamoraby
 */
public class ComponentDAO_imp implements ComponentDAO {

    @Override
    public boolean VerifyComponentID(Component c) throws SQLException {
        //connected to db

        //jdbc:derby://localhost:1527/CompanyDB
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "abc";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "SELECT * FROM Component WHERE ComponentID = '" + c.getComp_id() + "'";
        pst = con.prepareStatement(sqlQuery);
        rs = pst.executeQuery();
        while (rs.next()) {
            System.out.println(rs.getString("component ID"));
            return true;
        }
        return false;
        //Then check if it's assigned to this client
    }
    
        @Override
    public LinkedList<Component> GetComponents() throws SQLException {
        LinkedList<Component> components = new LinkedList<>();
        //connected to db

        //jdbc:derby://localhost:1527/CompanyDB
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "abc";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "SELECT * FROM Component";
        pst = con.prepareStatement(sqlQuery);
        rs = pst.executeQuery();
        while (rs.next()) {

            Component c = new Component("1", "name", "type", 100);
            components.add(c);
        }
        return components;
    }

}
