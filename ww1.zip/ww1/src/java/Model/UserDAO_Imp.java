/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author adhamoraby
 */
public class UserDAO_Imp implements UserDAO{
    ArrayList<File> files;
    ArrayList<String> notify = new ArrayList<>();

    @Override
    public boolean login(String username, String password) {
        if (username.equals("admin123") && password.equals("1234")) {
            return true;
        } else {
            return false;

        }
    }

    @Override
    public boolean sendmsg(String to, String from, String msg) {
        if (to.equals("admin2")) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean lookforitem(String itemName) {
        if (itemName.equals("item1")) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void uploadfile(File f) {
        files.add(f);
    }

    @Override
    public boolean deleteFile(String filename) {
        for (int i = 0; i < files.size(); i++) {
            if (files.get(i).getFileName().equals(filename)) {
                files.remove(i);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean downloadfile(String fname) {
        for (int i = 0; i < files.size(); i++) {
            if (files.get(i).getFileName().equals(fname)) {
                return true;
            }
        }
        return false;
    }
    public void Add (String s){
        notify.add(s);
        
    }
}

    
