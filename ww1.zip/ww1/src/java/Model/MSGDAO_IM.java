/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author boica
 */
public class MSGDAO_IM implements MSGDAO {

    @Override
    public boolean sendmsg(Message m) throws SQLException {

        //jdbc:derby://localhost:1527/project
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "abc";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "INSERT INTO MESSAGE(MSG,SENDER,RECIVER) VALUES (?,?,?)";

        pst = con.prepareStatement(sqlQuery);

        pst.setString(1, m.message);
        pst.setString(2, m.sender);
        pst.setString(3, m.reciver);
        pst.executeUpdate();

        con.close();

        return true;
    }

    public static void main(String[] args) throws SQLException {
        MSGDAO_IM d = new MSGDAO_IM();
        System.out.println(d.sendmsg(new Message("aga", "fff", "ada")));

    }

}
