/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

/**
 *
 * @author boica
 */
public class ProjectDAO_IM implements ProjectDAO {

    @Override
    public boolean verifyProjectID(Project Project) throws SQLException {
        //connected to db

        String host = "jdbc:derby://localhost:1527/project";
        String uName = "abc";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "SELECT * FROM PROJECT WHERE PROJECID = '" + Project.getP_ID()+ "'";
        pst = con.prepareStatement(sqlQuery);
        rs = pst.executeQuery();
        while (rs.next()) {
            System.out.println(rs.getString("PROJECID"));
            return true;
        }
        return false;
        //Then check if it's assigned to this client
    }

    @Override
    public LinkedList<Project> getAllProjects() throws SQLException {
        LinkedList<Project> projects = new LinkedList<>();
        //connected to db

        //jdbc:derby://localhost:1527/CompanyDB
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "abc";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "SELECT * FROM project";
        pst = con.prepareStatement(sqlQuery);
        rs = pst.executeQuery();
        while (rs.next()) {
            String ProjectID = rs.getString("PROJECTID");
            String projectname = rs.getString("PROJECTNAME");

            Project p = new Project(ProjectID, projectname);
            projects.add(p);
        }
        return projects;
    }

    
    //add component from component table in database to project table in database   
    @Override
    public boolean add_Comp_to_project(String compID) throws SQLException {
        //connected to db

        //jdbc:derby://localhost:1527/CompanyDB
        String host = "jdbc:derby://localhost:1527/project";
        String uName = "abc";
        String password = "1234";

        Connection con = DriverManager.getConnection(host, uName, password);
        //check if contract exists

        PreparedStatement pst = null;
        ResultSet rs = null;

        String sqlQuery = "UPDATE PROJECT SET(COMP_ID) VALUES (?)";
        pst = con.prepareStatement(sqlQuery);

        pst.setString(1, compID);

        pst.executeUpdate();

        con.close();

        return true;
}




}
