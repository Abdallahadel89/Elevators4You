/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Model;

/**
 *
 * @author adhamoraby
 */
public interface UserDAO {
    public boolean login(String username, String password);
    public boolean sendmsg(String to, String from, String msg);
    public boolean lookforitem(String itemName);
    public void uploadfile(File f);
    public boolean deleteFile(String filename);
    public boolean downloadfile(String fname);
}
    

