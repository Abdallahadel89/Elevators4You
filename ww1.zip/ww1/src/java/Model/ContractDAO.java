/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.SQLException;
import java.util.LinkedList;

/**
 *
 * @author seife
 */
public interface ContractDAO {

    public LinkedList<Contract> getAllContracts() throws SQLException;

    public boolean verifyContractID(Contract contract) throws SQLException;
    
    public boolean insertContractData(Contract c) throws SQLException;
    
    public boolean EditContract(Contract c) throws SQLException;
}
